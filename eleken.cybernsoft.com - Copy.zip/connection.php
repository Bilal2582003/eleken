<?php


$database="eleken";
$username="root";
$password="";
$hostname="localhost";


// $database="cyberns2_eleken";
// $username="cyberns2_saimagroup";
// $password="03172746242dA";
// $hostname="localhost";

// $conn= mysqli_connect($hostname,$username,$password,$database) or die("Connection failed");


// $database="cyberns2_eleken";
// $username="cyberns2_saimagroup";
// $password="03172746242dA";
// $hostname="localhost";

$con= mysqli_connect($hostname,$username,$password,$database) or die("Connection failed");


?>